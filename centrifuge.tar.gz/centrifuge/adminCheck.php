<?php
$isAdmin=in_array($_SERVER['cn'],json_decode(file_get_contents("whitelist.txt")));
?>
